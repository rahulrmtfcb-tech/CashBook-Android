# CashBook V14.3.1 – Animation + Tutorial Fix

CashBook personal finance app with RMT Labs branding.

## V14.3 fixes
- Reliable native animated splash and startup sequence.
- First-run tutorial uses a new version key and is forced visible on this release if needed.
- Native splash has a clearly visible spin/zoom/fade animation and release label V14.3.1.
- People tab rendering fixed.
- Loan Given repayment is loan-linked and avoids double-counting legacy repayments.
- Loan Taken payment supports selecting the exact loan and stores loanId.
- EMI paid history supports actual paid amount and dividend-adjusted payable.
- Native EMI/loan reminders can be cancelled when fully paid/deleted.
- Phone notification tap opens the relevant EMI/loan payment flow.
- Notification permission request is delayed until after startup splash.
- Restore validates backup structure and creates a safety export before replacing data.
- Monthly Summary includes income, expenses, loans, repayments, EMI and currency transfers.
- AED/INR and other supported currency transfers affect only the source/destination balances.
- Launcher/notification icon resource remains bundled.

## Build
GitHub Actions uses Java 17 and Gradle.
