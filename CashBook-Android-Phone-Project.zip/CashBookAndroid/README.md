# CashBook Android

Android WebView wrapper for the supplied CashBook V9 HTML app.

## Phone-only build
You can build this project from an Android device using a compatible Android Gradle IDE/terminal, or use the included GitHub Actions workflow. The workflow builds `app-debug.apk` automatically after you push the project to a GitHub repository.

The HTML app is bundled locally, so normal CashBook data is stored in WebView local storage on the device.
