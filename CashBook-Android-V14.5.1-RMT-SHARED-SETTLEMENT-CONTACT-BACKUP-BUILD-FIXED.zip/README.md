# CashBook V14.4.3 – Animation + Tutorial Fix

CashBook personal finance app with RMT Labs branding.

## V14.3 fixes
- Reliable native animated splash and startup sequence.
- First-run tutorial uses a new version key and is forced visible on this release if needed.
- Native splash has a clearly visible spin/zoom/fade animation and release label V14.4.3.
- People tab rendering fixed.
- Loan Given repayment is loan-linked and avoids double-counting legacy repayments.
- Loan Taken payment supports selecting the exact loan and stores loanId.
- EMI paid history supports actual paid amount and dividend-adjusted payable.
- Native EMI/loan reminders can be cancelled when fully paid/deleted.
- Phone notification tap opens the relevant EMI/loan payment flow.
- Notification permission request is delayed until after startup splash.
- Restore validates backup structure and creates a safety export before replacing data.
- Monthly Summary includes income, expenses, loans, repayments, EMI and currency transfers.
- AED/INR and other supported currency transfers affect only the source/destination balances.
- Launcher/notification icon resource remains bundled.

## Build
GitHub Actions uses Java 17 and Gradle.


## V14.4.0 FIX
- Native Android splash is authoritative; duplicate HTML splash is removed after load.
- First-launch tutorial version bumped to 14.4.0 so existing 14.3.x tutorial state does not suppress onboarding.
- Version metadata and GitHub Actions artifact updated to V14.4.0.

## V14.5.1 updates
- Shared Expense now supports both directions: Pay or Receive.
- Shared Expense settlement supports partial and full clearing; Pay creates an Expense and Receive creates Income.
- Person phone number can be selected directly from the device Contacts picker.
- Backup screen includes Email Backup.
- Account/cloud sync UI is included as a documented integration point; real automatic cross-device restore requires a configured cloud backend such as Firebase.


## V14.5.1 build fix
The GitHub Actions workflow now installs and uses Gradle 8.7 explicitly, avoiding the previous `gradle: command not found` failure. Android Gradle Plugin remains 8.6.1 with Java 17.
