package com.cashbook.app;

import android.Manifest;
import android.provider.ContactsContract;
import android.database.Cursor;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int FILE_CHOOSER = 1001;
    private static final int NOTIFICATION_PERMISSION = 1002;
    private static final int CONTACT_PICKER = 1003;
    private android.webkit.ValueCallback<Uri[]> filePathCallback;
    private String pendingNotificationType;
    private String pendingNotificationId;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pendingNotificationType = getIntent().getStringExtra("cashbook_type");
        pendingNotificationId = getIntent().getStringExtra("cashbook_id");
        showAnimatedSplash();
    }

    private void showAnimatedSplash() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.cashbook_splash);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                -1, -1, Gravity.CENTER);
        lp.leftMargin = 18;
        lp.rightMargin = 18;
        lp.topMargin = 24;
        lp.bottomMargin = 24;
        root.addView(logo, lp);
        setContentView(root);

        // Animate the supplied original CashBook + RMT Labs artwork as one unit.
        logo.setAlpha(0f);
        logo.setTranslationY(28f);
        logo.setScaleX(.88f);
        logo.setScaleY(.88f);
        logo.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setDuration(1100)
                .setInterpolator(new AccelerateDecelerateInterpolator())
                .start();

        new Handler().postDelayed(this::openCashBook, 4000);
    }

    private void openCashBook() {
        FrameLayout root=new FrameLayout(this);webView=new WebView(this);root.addView(webView,new FrameLayout.LayoutParams(-1,-1));setContentView(root);
        WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);s.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new NativeBridge(this),"CashBookNative");webView.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView view, String url){
                super.onPageFinished(view,url);
                new Handler().postDelayed(() -> {
                    view.evaluateJavascript("(function(){try{if(typeof startAfterNativeSplash===\"function\"){startAfterNativeSplash();}else if(typeof startTutorial===\"function\"){startTutorial(false);}}catch(e){}})();", null);
                    if (pendingNotificationType != null && pendingNotificationId != null) {
                        String js = "try{if(typeof handleNativeNotification==='function'){handleNativeNotification(" + JSONObject.quote(pendingNotificationType) + "," + JSONObject.quote(pendingNotificationId) + ");}}catch(e){}";
                        view.evaluateJavascript(js, null);
                        pendingNotificationType = null;
                        pendingNotificationId = null;
                    }
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        new Handler().postDelayed(() -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION), 500);
                    }
                }, 350);
            }
        });
        webView.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView view,android.webkit.ValueCallback<Uri[]> cb,FileChooserParams params){if(filePathCallback!=null)filePathCallback.onReceiveValue(null);filePathCallback=cb;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,FILE_CHOOSER);return true;}});
        webView.setDownloadListener((url,userAgent,contentDisposition,mimeType,contentLength)->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ignored){}});
        webView.loadUrl("file:///android_asset/CashBook.html");
    }

    public static class NativeBridge {
        private final Context context; private final Activity activity; NativeBridge(Activity a){activity=a;context=a.getApplicationContext();}
        @JavascriptInterface public void scheduleReminder(String type,String id,String due,String title,String text){
            try{Calendar dueCal=Calendar.getInstance();DateParts parts=DateParts.parse(due);dueCal.set(parts.y,parts.m-1,parts.d,9,0,0);dueCal.set(Calendar.MILLISECOND,0);dueCal.add(Calendar.DAY_OF_YEAR,-7);if(dueCal.getTimeInMillis()<=System.currentTimeMillis())return;int request=Math.abs((type+":"+id).hashCode());Intent i=new Intent(context,ReminderReceiver.class).putExtra("title",title).putExtra("text",text).putExtra("cashbook_type",type).putExtra("cashbook_id",id);PendingIntent pi=PendingIntent.getBroadcast(context,request,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)context.getSystemService(ALARM_SERVICE);am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,dueCal.getTimeInMillis(),pi);}catch(Exception ignored){}
        }
        @JavascriptInterface public void pickContact(){
            Activity a=activity;
            if(Build.VERSION.SDK_INT>=23 && a.checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){
                a.requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},CONTACT_PICKER);
                return;
            }
            Intent i=new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
            a.startActivityForResult(i,CONTACT_PICKER);
        }
        @JavascriptInterface public void emailBackup(String json){
            try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_EMAIL,new String[]{""});i.putExtra(Intent.EXTRA_SUBJECT,"CashBook Backup");i.putExtra(Intent.EXTRA_TEXT,json);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);context.startActivity(Intent.createChooser(i,"Send CashBook Backup"));}catch(Exception ignored){}
        }
        @JavascriptInterface public void cancelReminder(String type,String id){
            try{int request=Math.abs((type+":"+id).hashCode());Intent i=new Intent(context,ReminderReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(context,request,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)context.getSystemService(ALARM_SERVICE);am.cancel(pi);pi.cancel();}catch(Exception ignored){}
        }
    }
    static class DateParts{int y,m,d;static DateParts parse(String s){DateParts p=new DateParts();p.y=Integer.parseInt(s.substring(0,4));p.m=Integer.parseInt(s.substring(5,7));p.d=Integer.parseInt(s.substring(8,10));return p;}}

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==CONTACT_PICKER&&grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED){try{Intent i=new Intent(Intent.ACTION_PICK,ContactsContract.CommonDataKinds.Phone.CONTENT_URI);startActivityForResult(i,CONTACT_PICKER);}catch(Exception ignored){}}}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==FILE_CHOOSER&&filePathCallback!=null){Uri[] r=(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)?new Uri[]{data.getData()}:null;filePathCallback.onReceiveValue(r);filePathCallback=null;}else if(requestCode==CONTACT_PICKER&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&webView!=null){Uri uri=data.getData();Cursor c=null;try{String[] proj={ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER};c=getContentResolver().query(uri,proj,null,null,null);if(c!=null&&c.moveToFirst()){String name=c.getString(c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));String phone=c.getString(c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER));webView.evaluateJavascript("setPickedContact("+JSONObject.quote(name)+","+JSONObject.quote(phone)+")",null);}}catch(Exception ignored){}finally{if(c!=null)c.close();}}}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
