package com.cashbook.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int FILE_CHOOSER = 1001;
    private static final int NOTIFICATION_PERMISSION = 1002;
    private android.webkit.ValueCallback<Uri[]> filePathCallback;
    private String pendingNotificationType;
    private String pendingNotificationId;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pendingNotificationType = getIntent().getStringExtra("cashbook_type");
        pendingNotificationId = getIntent().getStringExtra("cashbook_id");
        showAnimatedSplash();
    }

    private void showAnimatedSplash() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(245,247,251));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(32,24,32,24);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_cashbook_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        box.addView(logo, new LinearLayout.LayoutParams(132,132));

        TextView title = new TextView(this);
        title.setText("CashBook");
        title.setTextColor(Color.rgb(23,32,51));
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-2,-2);
        tp.topMargin=14;
        box.addView(title,tp);

        TextView powered = new TextView(this);
        powered.setText("Powered by RMT Labs");
        powered.setTextColor(Color.rgb(37,99,235));
        powered.setTextSize(14);
        powered.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-2,-2);
        pp.topMargin=6;
        box.addView(powered,pp);

        TextView loading = new TextView(this);
        loading.setText("Personal finance, made simple");
        loading.setTextColor(Color.rgb(113,128,150));
        loading.setTextSize(12);
        loading.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);
        lp.topMargin=10;
        box.addView(loading,lp);

        TextView ver = new TextView(this);
        ver.setText("V14.4.0");
        ver.setTextColor(Color.rgb(140,150,165));
        ver.setTextSize(11);
        ver.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(-2,-2);
        vp.topMargin=8;
        box.addView(ver,vp);

        root.addView(box,new FrameLayout.LayoutParams(-2,-2,Gravity.CENTER));
        setContentView(root);

        // Very visible native animation: fade + zoom + spin + lift, then settle.
        box.setAlpha(0f);
        box.setTranslationY(34f);
        box.setScaleX(.72f);
        box.setScaleY(.72f);
        box.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setDuration(900).setInterpolator(new AccelerateDecelerateInterpolator()).start();

        logo.setRotation(-30f);
        logo.animate().rotationBy(390f).setDuration(1400)
                .setInterpolator(new AccelerateDecelerateInterpolator()).start();
        logo.animate().scaleX(1.08f).scaleY(1.08f).setDuration(500)
                .setStartDelay(700).setInterpolator(new AccelerateDecelerateInterpolator()).start();
        logo.animate().scaleX(1f).scaleY(1f).setDuration(450)
                .setStartDelay(1200).setInterpolator(new AccelerateDecelerateInterpolator()).start();

        title.setAlpha(0f); powered.setAlpha(0f); loading.setAlpha(0f); ver.setAlpha(0f);
        title.animate().alpha(1f).setStartDelay(450).setDuration(450).start();
        powered.animate().alpha(1f).setStartDelay(700).setDuration(450).start();
        loading.animate().alpha(1f).setStartDelay(900).setDuration(450).start();
        ver.animate().alpha(1f).setStartDelay(1100).setDuration(400).start();

        new Handler().postDelayed(this::openCashBook,3200);
    }

    private void openCashBook() {
        FrameLayout root=new FrameLayout(this);webView=new WebView(this);root.addView(webView,new FrameLayout.LayoutParams(-1,-1));setContentView(root);
        WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);s.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new NativeBridge(this),"CashBookNative");webView.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView view, String url){
                super.onPageFinished(view,url);
                new Handler().postDelayed(() -> {
                    view.evaluateJavascript("(function(){try{if(typeof startAfterNativeSplash===\"function\"){startAfterNativeSplash();}else if(typeof startTutorial===\"function\"){startTutorial(false);}}catch(e){}})();", null);
                    if (pendingNotificationType != null && pendingNotificationId != null) {
                        String js = "try{if(typeof handleNativeNotification==='function'){handleNativeNotification(" + JSONObject.quote(pendingNotificationType) + "," + JSONObject.quote(pendingNotificationId) + ");}}catch(e){}";
                        view.evaluateJavascript(js, null);
                        pendingNotificationType = null;
                        pendingNotificationId = null;
                    }
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        new Handler().postDelayed(() -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION), 500);
                    }
                }, 350);
            }
        });
        webView.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView view,android.webkit.ValueCallback<Uri[]> cb,FileChooserParams params){if(filePathCallback!=null)filePathCallback.onReceiveValue(null);filePathCallback=cb;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,FILE_CHOOSER);return true;}});
        webView.setDownloadListener((url,userAgent,contentDisposition,mimeType,contentLength)->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ignored){}});
        webView.loadUrl("file:///android_asset/CashBook.html");
    }

    public static class NativeBridge {
        private final Context context; NativeBridge(Context c){context=c.getApplicationContext();}
        @JavascriptInterface public void scheduleReminder(String type,String id,String due,String title,String text){
            try{Calendar dueCal=Calendar.getInstance();DateParts parts=DateParts.parse(due);dueCal.set(parts.y,parts.m-1,parts.d,9,0,0);dueCal.set(Calendar.MILLISECOND,0);dueCal.add(Calendar.DAY_OF_YEAR,-7);if(dueCal.getTimeInMillis()<=System.currentTimeMillis())return;int request=Math.abs((type+":"+id).hashCode());Intent i=new Intent(context,ReminderReceiver.class).putExtra("title",title).putExtra("text",text).putExtra("cashbook_type",type).putExtra("cashbook_id",id);PendingIntent pi=PendingIntent.getBroadcast(context,request,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)context.getSystemService(ALARM_SERVICE);am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,dueCal.getTimeInMillis(),pi);}catch(Exception ignored){}
        }
        @JavascriptInterface public void cancelReminder(String type,String id){
            try{int request=Math.abs((type+":"+id).hashCode());Intent i=new Intent(context,ReminderReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(context,request,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)context.getSystemService(ALARM_SERVICE);am.cancel(pi);pi.cancel();}catch(Exception ignored){}
        }
    }
    static class DateParts{int y,m,d;static DateParts parse(String s){DateParts p=new DateParts();p.y=Integer.parseInt(s.substring(0,4));p.m=Integer.parseInt(s.substring(5,7));p.d=Integer.parseInt(s.substring(8,10));return p;}}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==FILE_CHOOSER&&filePathCallback!=null){Uri[] r=(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)?new Uri[]{data.getData()}:null;filePathCallback.onReceiveValue(r);filePathCallback=null;}}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
