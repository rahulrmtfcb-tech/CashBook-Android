# CashBook Android V14.6.0 — RMT Security Build Fix 2

This build fixes the V14.6.0 biometric compilation errors.

## Security
- CashBook password lock with SHA-256 stored hash.
- Android system Fingerprint / Face biometric unlock via `android.hardware.biometrics.BiometricPrompt`.
- Password fallback when biometric is unavailable or cancelled.
- Biometric data is handled by the Android OS; CashBook does not store biometric data.

## Build
- Android Gradle Plugin: 8.6.1
- Gradle: 8.7
- Java: 17
- compileSdk: 35
- targetSdk: 35
- minSdk: 23

## Included features
- RMT Labs animated splash (4 seconds)
- Shared Expense settlement
- Phone contact picker
- Backup / restore flow
- EMI and repayment reminders
- AED / INR currency support
- GitHub Actions debug APK build
