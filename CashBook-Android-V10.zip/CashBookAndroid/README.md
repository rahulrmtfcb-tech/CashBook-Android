# CashBook V10.2 — RMT Labs

Personal Finance Manager Android app.

## Branding
- Supplied CashBook/RMT Labs artwork is used for the launch screen.
- Launcher icon uses the CashBook emblem from the supplied artwork.
- In-app header and footer are branded for RMT Labs.

## Build
Run the GitHub Actions workflow **Build CashBook APK**. The workflow produces a debug APK artifact.
