# CashBook Android V10

CashBook personal finance tracker packaged as an Android WebView app.

## V10 updates
- Added **Loan Taken** entry from the + menu.
- Loan Taken is added to the selected currency balance because money is received.
- Monthly Summary now includes Loans Taken and Loan Payments fields.
- Added Loans Taken transaction filter and summary section.
- Loan/EMI in-app reminders now appear up to **7 days before** the due date.
- Backup export version updated to V10.
- Android version bumped to 1.0.10 / versionCode 10.

## Build
Open the project in Android Studio or run `gradle :app:assembleDebug` on a machine with Gradle installed.
