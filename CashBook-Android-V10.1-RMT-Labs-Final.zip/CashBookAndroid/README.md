# CashBook V10.1 — RMT Labs

Personal finance control app for income, expenses, loans given/taken, repayments, EMI, currency exchange, reminders, people, monthly summaries, and backup/restore.

## Included in this build
- Loan Given and Loan Taken
- Loan repayment amount entry from reminders
- EMI with fixed/dividend-adjusted payment support
- EMI paid history and monthly summary
- AED/INR/USD/SAR currency tracking and exchange
- Only non-zero current currency balances are shown
- Hamburger menu for personal data, backup/restore, settings and monthly summary
- Floating + action menu
- In-app repayment/EMI reminders up to 7 days before due date
- RMT Labs branded splash screen
- Custom CashBook app icon
- Android WebView packaging

Version: 1.0.11 (versionCode 11)
