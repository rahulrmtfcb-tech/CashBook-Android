package com.cashbook.app;

import android.Manifest;
import android.provider.ContactsContract;
import android.database.Cursor;
import android.app.Activity;
import android.app.AlertDialog;
import android.hardware.biometrics.BiometricPrompt;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.CancellationSignal;
import java.security.MessageDigest;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int FILE_CHOOSER = 1001;
    private static final int NOTIFICATION_PERMISSION = 1002;
    private static final int CONTACT_PICKER = 1003;
    private android.webkit.ValueCallback<Uri[]> filePathCallback;
    private String pendingNotificationType;
    private String pendingNotificationId;
    private static final String AUTH_PREFS = "cashbook_auth";
    private static final String PASSWORD_HASH = "password_hash";
    private final Executor biometricExecutor = Executors.newSingleThreadExecutor();

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pendingNotificationType = getIntent().getStringExtra("cashbook_type");
        pendingNotificationId = getIntent().getStringExtra("cashbook_id");
        showAnimatedSplash();
    }

    private void showAnimatedSplash() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.cashbook_splash);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                -1, -1, Gravity.CENTER);
        lp.leftMargin = 18;
        lp.rightMargin = 18;
        lp.topMargin = 24;
        lp.bottomMargin = 24;
        root.addView(logo, lp);
        setContentView(root);

        // Animate the supplied original CashBook + RMT Labs artwork as one unit.
        logo.setAlpha(0f);
        logo.setTranslationY(28f);
        logo.setScaleX(.88f);
        logo.setScaleY(.88f);
        logo.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setDuration(1100)
                .setInterpolator(new AccelerateDecelerateInterpolator())
                .start();

        new Handler().postDelayed(this::authenticateThenOpen, 4000);
    }

    private void authenticateThenOpen() {
        SharedPreferences prefs = getSharedPreferences(AUTH_PREFS, MODE_PRIVATE);
        if (!prefs.contains(PASSWORD_HASH)) {
            showCreatePasswordDialog();
        } else {
            showUnlockDialog();
        }
    }

    private void showCreatePasswordDialog() { createPasswordValidated(); }

    private void createPasswordValidated() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL); box.setPadding(40, 10, 40, 0);
        final android.widget.EditText first = new android.widget.EditText(this); first.setHint("Create password"); first.setInputType(0x00000081);
        final android.widget.EditText second = new android.widget.EditText(this); second.setHint("Confirm password"); second.setInputType(0x00000081);
        box.addView(first); box.addView(second);
        AlertDialog d = new AlertDialog.Builder(this).setTitle("Secure CashBook").setMessage("Create a password for CashBook.").setView(box).setCancelable(false).setPositiveButton("Save", null).show();
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String a=first.getText().toString(), b=second.getText().toString();
            if(a.length()<4){first.setError("Use at least 4 characters");return;}
            if(!a.equals(b)){second.setError("Passwords do not match");return;}
            getSharedPreferences(AUTH_PREFS,MODE_PRIVATE).edit().putString(PASSWORD_HASH,hash(a)).apply();
            d.dismiss(); openCashBook();
        });
    }

    private void showUnlockDialog() {
        final android.widget.EditText input = new android.widget.EditText(this);
        input.setHint("Password"); input.setInputType(0x00000081); input.setSingleLine(true);
        AlertDialog d = new AlertDialog.Builder(this).setTitle("Unlock CashBook").setMessage("Enter your password or use biometric unlock.").setView(input).setCancelable(false).setPositiveButton("Unlock", null).setNegativeButton("Biometric", null).show();
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String stored=getSharedPreferences(AUTH_PREFS,MODE_PRIVATE).getString(PASSWORD_HASH,"");
            if(hash(input.getText().toString()).equals(stored)){d.dismiss();openCashBook();}else input.setError("Incorrect password");
        });
        d.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> { d.dismiss(); showBiometricPrompt(); });
    }

    private void showBiometricPrompt() {
        if(Build.VERSION.SDK_INT<28){ showUnlockDialog(); return; }
        // BiometricPrompt is available from API 28. BiometricManager.canAuthenticate() is
        // only used on API 29+ so API 28 devices do not hit a newer framework class.
        if (Build.VERSION.SDK_INT >= 29) {
            android.hardware.biometrics.BiometricManager bm=(android.hardware.biometrics.BiometricManager)getSystemService(BIOMETRIC_SERVICE);
            if(bm==null || bm.canAuthenticate()!=android.hardware.biometrics.BiometricManager.BIOMETRIC_SUCCESS){
                new AlertDialog.Builder(this).setTitle("Biometric unavailable").setMessage("Set up fingerprint or face unlock in your phone settings, or use your CashBook password.").setPositiveButton("OK",(d,w)->showUnlockDialog()).show();
                return;
            }
        }
        BiometricPrompt prompt=new BiometricPrompt.Builder(this).setTitle("Unlock CashBook").setSubtitle("Use your fingerprint or device biometric").setDescription("Your biometric stays on the device and is not stored by CashBook.").setNegativeButton("Use password", getMainExecutor(), (d,w)->showUnlockDialog()).build();
        prompt.authenticate(new CancellationSignal(), getMainExecutor(), new BiometricPrompt.AuthenticationCallback(){
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result){runOnUiThread(MainActivity.this::openCashBook);}
            @Override public void onAuthenticationError(int errorCode, CharSequence errString){if(errorCode!=BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED && errorCode!=BiometricPrompt.BIOMETRIC_ERROR_CANCELED) runOnUiThread(MainActivity.this::showUnlockDialog);}
        });
    }

    private String hash(String value){try{byte[] b=MessageDigest.getInstance("SHA-256").digest(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format(Locale.US,"%02x",x));return s.toString();}catch(Exception e){return value;}}

    private void openCashBook() {
        FrameLayout root=new FrameLayout(this);webView=new WebView(this);root.addView(webView,new FrameLayout.LayoutParams(-1,-1));setContentView(root);
        WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);s.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new NativeBridge(this),"CashBookNative");webView.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView view, String url){
                super.onPageFinished(view,url);
                new Handler().postDelayed(() -> {
                    view.evaluateJavascript("(function(){try{if(typeof startAfterNativeSplash===\"function\"){startAfterNativeSplash();}else if(typeof startTutorial===\"function\"){startTutorial(false);}}catch(e){}})();", null);
                    if (pendingNotificationType != null && pendingNotificationId != null) {
                        String js = "try{if(typeof handleNativeNotification==='function'){handleNativeNotification(" + JSONObject.quote(pendingNotificationType) + "," + JSONObject.quote(pendingNotificationId) + ");}}catch(e){}";
                        view.evaluateJavascript(js, null);
                        pendingNotificationType = null;
                        pendingNotificationId = null;
                    }
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        new Handler().postDelayed(() -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION), 500);
                    }
                }, 350);
            }
        });
        webView.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView view,android.webkit.ValueCallback<Uri[]> cb,FileChooserParams params){if(filePathCallback!=null)filePathCallback.onReceiveValue(null);filePathCallback=cb;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,FILE_CHOOSER);return true;}});
        webView.setDownloadListener((url,userAgent,contentDisposition,mimeType,contentLength)->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ignored){}});
        webView.loadUrl("file:///android_asset/CashBook.html");
    }

    public static class NativeBridge {
        private final Context context; private final Activity activity; NativeBridge(Activity a){activity=a;context=a.getApplicationContext();}
        @JavascriptInterface public void scheduleReminder(String type,String id,String due,String title,String text){
            try{Calendar dueCal=Calendar.getInstance();DateParts parts=DateParts.parse(due);dueCal.set(parts.y,parts.m-1,parts.d,9,0,0);dueCal.set(Calendar.MILLISECOND,0);dueCal.add(Calendar.DAY_OF_YEAR,-7);if(dueCal.getTimeInMillis()<=System.currentTimeMillis())return;int request=Math.abs((type+":"+id).hashCode());Intent i=new Intent(context,ReminderReceiver.class).putExtra("title",title).putExtra("text",text).putExtra("cashbook_type",type).putExtra("cashbook_id",id);PendingIntent pi=PendingIntent.getBroadcast(context,request,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)context.getSystemService(ALARM_SERVICE);am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,dueCal.getTimeInMillis(),pi);}catch(Exception ignored){}
        }
        @JavascriptInterface public void pickContact(){
            Activity a=activity;
            if(Build.VERSION.SDK_INT>=23 && a.checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){
                a.requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},CONTACT_PICKER);
                return;
            }
            Intent i=new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
            a.startActivityForResult(i,CONTACT_PICKER);
        }
        @JavascriptInterface public void emailBackup(String json){
            try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_EMAIL,new String[]{""});i.putExtra(Intent.EXTRA_SUBJECT,"CashBook Backup");i.putExtra(Intent.EXTRA_TEXT,json);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);context.startActivity(Intent.createChooser(i,"Send CashBook Backup"));}catch(Exception ignored){}
        }
        @JavascriptInterface public void cancelReminder(String type,String id){
            try{int request=Math.abs((type+":"+id).hashCode());Intent i=new Intent(context,ReminderReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(context,request,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)context.getSystemService(ALARM_SERVICE);am.cancel(pi);pi.cancel();}catch(Exception ignored){}
        }
    }
    static class DateParts{int y,m,d;static DateParts parse(String s){DateParts p=new DateParts();p.y=Integer.parseInt(s.substring(0,4));p.m=Integer.parseInt(s.substring(5,7));p.d=Integer.parseInt(s.substring(8,10));return p;}}

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==CONTACT_PICKER&&grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED){try{Intent i=new Intent(Intent.ACTION_PICK,ContactsContract.CommonDataKinds.Phone.CONTENT_URI);startActivityForResult(i,CONTACT_PICKER);}catch(Exception ignored){}}}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==FILE_CHOOSER&&filePathCallback!=null){Uri[] r=(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)?new Uri[]{data.getData()}:null;filePathCallback.onReceiveValue(r);filePathCallback=null;}else if(requestCode==CONTACT_PICKER&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&webView!=null){Uri uri=data.getData();Cursor c=null;try{String[] proj={ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER};c=getContentResolver().query(uri,proj,null,null,null);if(c!=null&&c.moveToFirst()){String name=c.getString(c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));String phone=c.getString(c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER));webView.evaluateJavascript("setPickedContact("+JSONObject.quote(name)+","+JSONObject.quote(phone)+")",null);}}catch(Exception ignored){}finally{if(c!=null)c.close();}}}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
