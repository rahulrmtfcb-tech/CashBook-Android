package com.cashbook.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.webkit.DownloadListener;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int FILE_CHOOSER = 1001;
    private android.webkit.ValueCallback<Uri[]> filePathCallback;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showAnimatedSplash();
    }

    private void showAnimatedSplash() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(245,247,251));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(32, 24, 32, 24);

        TextView icon = new TextView(this);
        icon.setText("💰");
        icon.setTextSize(48);
        icon.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(238,242,255));
        bg.setCornerRadius(38);
        icon.setBackground(bg);
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(92,92);
        ip.gravity = Gravity.CENTER_HORIZONTAL;
        box.addView(icon, ip);

        TextView title = new TextView(this);
        title.setText("CashBook");
        title.setTextColor(Color.rgb(23,32,51));
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2,-2);
        tp.topMargin = 18;
        box.addView(title,tp);

        TextView powered = new TextView(this);
        powered.setText("Powered by RMT Labs");
        powered.setTextColor(Color.rgb(37,99,235));
        powered.setTextSize(14);
        powered.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-2,-2);
        pp.topMargin = 6;
        box.addView(powered,pp);

        root.addView(box, new FrameLayout.LayoutParams(-2,-2,Gravity.CENTER));
        setContentView(root);

        box.setAlpha(0f); box.setScaleX(.88f); box.setScaleY(.88f);
        box.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650).setInterpolator(new AccelerateDecelerateInterpolator()).start();
        icon.animate().rotationBy(360f).setDuration(950).setInterpolator(new AccelerateDecelerateInterpolator()).start();
        title.setAlpha(0f); powered.setAlpha(0f);
        title.animate().alpha(1f).setStartDelay(350).setDuration(450).start();
        powered.animate().alpha(1f).setStartDelay(650).setDuration(450).start();

        new Handler().postDelayed(this::openCashBook, 1900);
    }

    private void openCashBook() {
        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, android.webkit.ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                startActivityForResult(i, FILE_CHOOSER);
                return true;
            }
        });
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            try { startActivity(i); } catch (Exception ignored) {}
        });
        webView.loadUrl("file:///android_asset/CashBook.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && filePathCallback != null) {
            Uri[] result = (resultCode == RESULT_OK && data != null && data.getData() != null)
                    ? new Uri[]{data.getData()} : null;
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
