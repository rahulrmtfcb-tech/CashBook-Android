# CashBook V11

Personal finance tracker by RMT Labs.

## V11 update
- Animated CashBook splash with Powered by RMT Labs
- First-use guided tutorial with Next/Skip
- Tutorial can be reopened from Menu
- Loan Given repayment validation and received flow
- Loan Taken repayment flow
- EMI paid history and dividend-adjusted payable tracking
- Monthly Summary for balances, income, expenses, loans, EMI and exchange
- Currency balances show only non-zero currencies
- Backup & Restore and personal data menu
