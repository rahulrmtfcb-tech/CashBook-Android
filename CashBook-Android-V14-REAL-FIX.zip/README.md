# CashBook V14 – REAL FIX

- Native animated splash only; removed the old HTML ₹ splash.
- CashBook + Powered by RMT Labs.
- Tutorial starts deterministically after the native splash and can be reopened from Menu.
- Fixed launcher icon resource reference.
- Version 14 labels and backup filename.
- Existing finance features retained.

Build with GitHub Actions using Java 17.
