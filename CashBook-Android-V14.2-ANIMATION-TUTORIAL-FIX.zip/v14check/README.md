# CashBook V14 – REAL FIX

- Native animated splash only; removed the old HTML ₹ splash.
- CashBook + Powered by RMT Labs.
- Native splash is held for 3 seconds so the animation is clearly visible. Tutorial uses a new versioned key (14.1), starts after the WebView is ready, and can be reopened from Menu.
- Fixed launcher icon resource reference.
- Version 14 labels and backup filename.
- Existing finance features retained.

Build with GitHub Actions using Java 17.


V14.2 fix: added a real WebView splash layer, forced fresh tutorial version, and delayed notification permission so startup animation is not obscured.
