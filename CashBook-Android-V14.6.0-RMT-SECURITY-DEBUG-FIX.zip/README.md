# CashBook V14.6.0 — RMT Labs

CashBook personal finance app for income, expenses, loans, shared expenses, EMI tracking, contacts, reminders, currency exchange, and backup/restore.

## V14.6.0 security and stability update
- 4-second animated CashBook / RMT Labs splash retained.
- First launch: create a local CashBook password (minimum 4 characters).
- Later launches: password unlock or device biometric unlock (fingerprint/face where supported by the phone).
- Password is stored as a SHA-256 hash in Android app-private preferences; the biometric data itself never enters CashBook.
- Existing shared-expense settlement, contact picker, backup/restore, EMI and 7-day reminder functionality retained.
- GitHub Actions uses Java 17 and Gradle 8.7 and builds a debug APK.

## Important
This version adds a local app lock. If the CashBook password is forgotten, the app does not provide a server-side password reset because there is no cloud authentication backend in this project.
