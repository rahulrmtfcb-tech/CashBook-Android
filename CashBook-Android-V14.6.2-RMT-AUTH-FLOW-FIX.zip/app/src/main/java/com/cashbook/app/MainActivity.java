package com.cashbook.app;

import android.Manifest;
import android.provider.ContactsContract;
import android.database.Cursor;
import android.app.Activity;
import android.app.AlertDialog;
import android.hardware.biometrics.BiometricPrompt;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.CancellationSignal;
import java.security.MessageDigest;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.widget.Button;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int FILE_CHOOSER = 1001;
    private static final int NOTIFICATION_PERMISSION = 1002;
    private static final int CONTACT_PICKER = 1003;
    private android.webkit.ValueCallback<Uri[]> filePathCallback;
    private String pendingNotificationType;
    private String pendingNotificationId;
    private static final String AUTH_PREFS = "cashbook_auth";
    private static final String PASSWORD_HASH = "password_hash";
    private static final String ACCOUNT_EMAIL = "account_email";
    private static final String ACCOUNT_NAME = "account_name";
    private static final String EMAIL_VERIFIED = "email_verified";
    private static final String SESSION = "session";
    private final Executor biometricExecutor = Executors.newSingleThreadExecutor();

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pendingNotificationType = getIntent().getStringExtra("cashbook_type");
        pendingNotificationId = getIntent().getStringExtra("cashbook_id");
        showAnimatedSplash();
    }

    private void showAnimatedSplash() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.cashbook_splash);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                -1, -1, Gravity.CENTER);
        lp.leftMargin = 18;
        lp.rightMargin = 18;
        lp.topMargin = 24;
        lp.bottomMargin = 24;
        root.addView(logo, lp);
        setContentView(root);

        // Animate the supplied original CashBook + RMT Labs artwork as one unit.
        logo.setAlpha(0f);
        logo.setTranslationY(28f);
        logo.setScaleX(.88f);
        logo.setScaleY(.88f);
        logo.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setDuration(1100)
                .setInterpolator(new AccelerateDecelerateInterpolator())
                .start();

        new Handler().postDelayed(this::showAuthWelcome, 4000);
    }

    private int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    private TextView title(String text, float size){
        TextView t=new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(Color.rgb(23,32,51));
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setPadding(0,dp(4),0,dp(4)); return t;
    }
    private Button actionButton(String text){
        Button b=new Button(this); b.setText(text); b.setTextSize(15); b.setAllCaps(false); b.setTextColor(Color.WHITE);
        GradientDrawable g=new GradientDrawable(); g.setColor(Color.rgb(37,99,235)); g.setCornerRadius(dp(14)); b.setBackground(g); return b;
    }
    private android.widget.EditText field(String hint, int inputType){
        android.widget.EditText e=new android.widget.EditText(this); e.setHint(hint); e.setTextSize(16); e.setSingleLine(true); e.setInputType(inputType); e.setPadding(dp(14),0,dp(14),0); return e;
    }

    private void showAuthWelcome(){
        SharedPreferences p=getSharedPreferences(AUTH_PREFS,MODE_PRIVATE);
        if(p.getBoolean(EMAIL_VERIFIED,false) && p.contains(PASSWORD_HASH)) { showUnlockDialog(); return; }
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER_HORIZONTAL); root.setPadding(dp(28),dp(28),dp(28),dp(28)); root.setBackgroundColor(Color.rgb(247,249,252));
        ImageView icon=new ImageView(this); icon.setImageResource(R.drawable.cashbook_icon); icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE); root.addView(icon,new LinearLayout.LayoutParams(-1,dp(110)));
        TextView h=title("Welcome to CashBook",26); h.setGravity(Gravity.CENTER); root.addView(h);
        TextView sub=new TextView(this); sub.setText("Powered by RMT Labs\nSecure your personal finance with your account."); sub.setTextSize(14); sub.setTextColor(Color.GRAY); sub.setGravity(Gravity.CENTER); root.addView(sub,new LinearLayout.LayoutParams(-1,dp(55)));
        Button login=actionButton("Login"); Button signup=actionButton("Sign Up");
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(52)); bp.setMargins(0,dp(12),0,0); root.addView(login,bp); root.addView(signup,bp);
        login.setOnClickListener(v->showLogin()); signup.setOnClickListener(v->showSignup()); setContentView(root);
    }

    private void showSignup(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(22),dp(8),dp(22),0);
        android.widget.EditText name=field("Full name",1|0x80000); android.widget.EditText email=field("Email address",0x21); box.addView(name,new LinearLayout.LayoutParams(-1,dp(52))); box.addView(email,new LinearLayout.LayoutParams(-1,dp(52)));
        TextView info=new TextView(this); info.setText("Step 1 of 3: Verify your email before creating the CashBook password."); info.setTextColor(Color.GRAY); info.setPadding(0,dp(10),0,dp(8)); box.addView(info);
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Create CashBook Account").setView(box).setNegativeButton("Back",(x,w)->showAuthWelcome()).setPositiveButton("Verify Email",null).create(); d.setCancelable(false); d.show();
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String n=name.getText().toString().trim(), e=email.getText().toString().trim(); if(n.isEmpty()){name.setError("Enter your name");return;} if(!android.util.Patterns.EMAIL_ADDRESS.matcher(e).matches()){email.setError("Enter a valid email");return;} getSharedPreferences(AUTH_PREFS,MODE_PRIVATE).edit().putString(ACCOUNT_NAME,n).putString(ACCOUNT_EMAIL,e).putBoolean(EMAIL_VERIFIED,false).apply(); d.dismiss(); showEmailVerification(e,true);});
    }

    private void showEmailVerification(String email, boolean signup){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(22),dp(8),dp(22),0);
        TextView t=new TextView(this); t.setText("We need to verify: " + email + "\n\nOpen your email app, then return here and confirm verification. A real server-side email verification service can be connected later without changing this flow."); t.setTextSize(15); t.setTextColor(Color.DKGRAY); box.addView(t);
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Email Verification").setView(box).setNegativeButton("Back",(x,w)->showAuthWelcome()).setPositiveButton("I Verified My Email",null).create(); d.setCancelable(false); d.show();
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{getSharedPreferences(AUTH_PREFS,MODE_PRIVATE).edit().putBoolean(EMAIL_VERIFIED,true).apply(); d.dismiss(); if(signup) showCreatePasswordDialog(); else showUnlockDialog();});
    }

    private void showLogin(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(22),dp(8),dp(22),0);
        android.widget.EditText email=field("Email address",0x21); box.addView(email,new LinearLayout.LayoutParams(-1,dp(52)));
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Login to CashBook").setMessage("Enter your email first. Password and biometric are shown only after account verification.").setView(box).setNegativeButton("Back",(x,w)->showAuthWelcome()).setPositiveButton("Continue",null).create(); d.setCancelable(false); d.show();
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String e=email.getText().toString().trim(); SharedPreferences p=getSharedPreferences(AUTH_PREFS,MODE_PRIVATE); if(!android.util.Patterns.EMAIL_ADDRESS.matcher(e).matches()){email.setError("Enter a valid email");return;} if(!e.equalsIgnoreCase(p.getString(ACCOUNT_EMAIL,""))){email.setError("No CashBook account found. Please Sign Up first.");return;} d.dismiss(); if(!p.getBoolean(EMAIL_VERIFIED,false)){showEmailVerification(e,false);} else if(p.contains(PASSWORD_HASH)){showUnlockDialog();} else {showCreatePasswordDialog();}});
    }

    private void showCreatePasswordDialog() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(22), dp(8), dp(22), 0);
        final android.widget.EditText first = field("Create password",0x00000081); final android.widget.EditText second = field("Confirm password",0x00000081); box.addView(first,new LinearLayout.LayoutParams(-1,dp(52))); box.addView(second,new LinearLayout.LayoutParams(-1,dp(52)));
        AlertDialog d = new AlertDialog.Builder(this).setTitle("Set CashBook Password").setMessage("Your email is verified. Now create your CashBook password.").setView(box).setCancelable(false).setPositiveButton("Save", null).setNegativeButton("Back",(x,w)->showAuthWelcome()).show();
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {String a=first.getText().toString(), b=second.getText().toString(); if(a.length()<6){first.setError("Use at least 6 characters");return;} if(!a.equals(b)){second.setError("Passwords do not match");return;} getSharedPreferences(AUTH_PREFS,MODE_PRIVATE).edit().putString(PASSWORD_HASH,hash(a)).putBoolean(SESSION,true).apply(); d.dismiss(); askEnableBiometric();});
    }

    private void askEnableBiometric(){
        new AlertDialog.Builder(this).setTitle("Enable biometric unlock?").setMessage("After your account and password are set, you can use fingerprint or face unlock on future launches.").setNegativeButton("Not now",(d,w)->openCashBook()).setPositiveButton("Enable",(d,w)->{d.dismiss();showBiometricPrompt();}).show();
    }

    private void showUnlockDialog() {
        final android.widget.EditText input = field("Password",0x00000081);
        AlertDialog d = new AlertDialog.Builder(this).setTitle("Unlock CashBook").setMessage("Your account is already verified. Enter your password or use biometric unlock.").setView(input).setCancelable(false).setPositiveButton("Unlock", null).setNegativeButton("Biometric", null).show();
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {String stored=getSharedPreferences(AUTH_PREFS,MODE_PRIVATE).getString(PASSWORD_HASH,""); if(hash(input.getText().toString()).equals(stored)){d.dismiss();getSharedPreferences(AUTH_PREFS,MODE_PRIVATE).edit().putBoolean(SESSION,true).apply();openCashBook();}else input.setError("Incorrect password");});
        d.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> { d.dismiss(); showBiometricPrompt(); });
    }

    private void showBiometricPrompt() {
        if(Build.VERSION.SDK_INT<28){ showUnlockDialog(); return; }
        // BiometricPrompt is available from API 28. BiometricManager.canAuthenticate() is
        // only used on API 29+ so API 28 devices do not hit a newer framework class.
        if (Build.VERSION.SDK_INT >= 29) {
            android.hardware.biometrics.BiometricManager bm=(android.hardware.biometrics.BiometricManager)getSystemService(BIOMETRIC_SERVICE);
            if(bm==null || bm.canAuthenticate()!=android.hardware.biometrics.BiometricManager.BIOMETRIC_SUCCESS){
                new AlertDialog.Builder(this).setTitle("Biometric unavailable").setMessage("Set up fingerprint or face unlock in your phone settings, or use your CashBook password.").setPositiveButton("OK",(d,w)->showUnlockDialog()).show();
                return;
            }
        }
        BiometricPrompt prompt=new BiometricPrompt.Builder(this).setTitle("Unlock CashBook").setSubtitle("Use your fingerprint or device biometric").setDescription("Your biometric stays on the device and is not stored by CashBook.").setNegativeButton("Use password", getMainExecutor(), (d,w)->showUnlockDialog()).build();
        prompt.authenticate(new CancellationSignal(), getMainExecutor(), new BiometricPrompt.AuthenticationCallback(){
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result){runOnUiThread(MainActivity.this::openCashBook);}
            @Override public void onAuthenticationError(int errorCode, CharSequence errString){if(errorCode!=BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED && errorCode!=BiometricPrompt.BIOMETRIC_ERROR_CANCELED) runOnUiThread(MainActivity.this::showUnlockDialog);}
        });
    }

    private String hash(String value){try{byte[] b=MessageDigest.getInstance("SHA-256").digest(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format(Locale.US,"%02x",x));return s.toString();}catch(Exception e){return value;}}

    private void openCashBook() {
        FrameLayout root=new FrameLayout(this);webView=new WebView(this);root.addView(webView,new FrameLayout.LayoutParams(-1,-1));setContentView(root);
        WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);s.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new NativeBridge(this),"CashBookNative");webView.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView view, String url){
                super.onPageFinished(view,url);
                new Handler().postDelayed(() -> {
                    view.evaluateJavascript("(function(){try{if(typeof startAfterNativeSplash===\"function\"){startAfterNativeSplash();}else if(typeof startTutorial===\"function\"){startTutorial(false);}}catch(e){}})();", null);
                    if (pendingNotificationType != null && pendingNotificationId != null) {
                        String js = "try{if(typeof handleNativeNotification==='function'){handleNativeNotification(" + JSONObject.quote(pendingNotificationType) + "," + JSONObject.quote(pendingNotificationId) + ");}}catch(e){}";
                        view.evaluateJavascript(js, null);
                        pendingNotificationType = null;
                        pendingNotificationId = null;
                    }
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        new Handler().postDelayed(() -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION), 500);
                    }
                }, 350);
            }
        });
        webView.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView view,android.webkit.ValueCallback<Uri[]> cb,FileChooserParams params){if(filePathCallback!=null)filePathCallback.onReceiveValue(null);filePathCallback=cb;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,FILE_CHOOSER);return true;}});
        webView.setDownloadListener((url,userAgent,contentDisposition,mimeType,contentLength)->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ignored){}});
        webView.loadUrl("file:///android_asset/CashBook.html");
    }

    public static class NativeBridge {
        private final Context context; private final Activity activity; NativeBridge(Activity a){activity=a;context=a.getApplicationContext();}
        @JavascriptInterface public void scheduleReminder(String type,String id,String due,String title,String text){
            try{Calendar dueCal=Calendar.getInstance();DateParts parts=DateParts.parse(due);dueCal.set(parts.y,parts.m-1,parts.d,9,0,0);dueCal.set(Calendar.MILLISECOND,0);dueCal.add(Calendar.DAY_OF_YEAR,-7);if(dueCal.getTimeInMillis()<=System.currentTimeMillis())return;int request=Math.abs((type+":"+id).hashCode());Intent i=new Intent(context,ReminderReceiver.class).putExtra("title",title).putExtra("text",text).putExtra("cashbook_type",type).putExtra("cashbook_id",id);PendingIntent pi=PendingIntent.getBroadcast(context,request,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)context.getSystemService(ALARM_SERVICE);am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,dueCal.getTimeInMillis(),pi);}catch(Exception ignored){}
        }
        @JavascriptInterface public void pickContact(){
            Activity a=activity;
            if(Build.VERSION.SDK_INT>=23 && a.checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){
                a.requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},CONTACT_PICKER);
                return;
            }
            Intent i=new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
            a.startActivityForResult(i,CONTACT_PICKER);
        }
        @JavascriptInterface public void emailBackup(String json){
            try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_EMAIL,new String[]{""});i.putExtra(Intent.EXTRA_SUBJECT,"CashBook Backup");i.putExtra(Intent.EXTRA_TEXT,json);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);context.startActivity(Intent.createChooser(i,"Send CashBook Backup"));}catch(Exception ignored){}
        }
        @JavascriptInterface public void cancelReminder(String type,String id){
            try{int request=Math.abs((type+":"+id).hashCode());Intent i=new Intent(context,ReminderReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(context,request,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)context.getSystemService(ALARM_SERVICE);am.cancel(pi);pi.cancel();}catch(Exception ignored){}
        }
    }
    static class DateParts{int y,m,d;static DateParts parse(String s){DateParts p=new DateParts();p.y=Integer.parseInt(s.substring(0,4));p.m=Integer.parseInt(s.substring(5,7));p.d=Integer.parseInt(s.substring(8,10));return p;}}

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==CONTACT_PICKER&&grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED){try{Intent i=new Intent(Intent.ACTION_PICK,ContactsContract.CommonDataKinds.Phone.CONTENT_URI);startActivityForResult(i,CONTACT_PICKER);}catch(Exception ignored){}}}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==FILE_CHOOSER&&filePathCallback!=null){Uri[] r=(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)?new Uri[]{data.getData()}:null;filePathCallback.onReceiveValue(r);filePathCallback=null;}else if(requestCode==CONTACT_PICKER&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&webView!=null){Uri uri=data.getData();Cursor c=null;try{String[] proj={ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER};c=getContentResolver().query(uri,proj,null,null,null);if(c!=null&&c.moveToFirst()){String name=c.getString(c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));String phone=c.getString(c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER));webView.evaluateJavascript("setPickedContact("+JSONObject.quote(name)+","+JSONObject.quote(phone)+")",null);}}catch(Exception ignored){}finally{if(c!=null)c.close();}}}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
