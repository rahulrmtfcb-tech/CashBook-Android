# CashBook V14.6.2 Authentication Flow

1. Launch: RMT Labs / CashBook creative splash.
2. Welcome screen: Login and Sign Up.
3. Never show Password or Biometric before account authentication.

## Sign Up
Name -> Email -> Email verification -> Create Password -> Confirm Password -> Optional biometric enrollment -> Dashboard.

## Login
Email -> Account/email verification -> Password -> Optional biometric unlock on subsequent launches -> Dashboard.

## Rules
- First launch must show Login / Sign Up, not the password/biometric screen.
- Biometric is an unlock convenience only after the account has been established.
- No blank white authentication state; show the CashBook/RMT Labs authentication UI.
