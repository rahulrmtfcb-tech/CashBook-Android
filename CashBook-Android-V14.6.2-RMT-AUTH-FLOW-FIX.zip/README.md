# CashBook V14.6.2 — RMT Security & Biometric Fix

This is a cleaned Android project for CashBook.

## Build
- Android Gradle Plugin 8.6.1
- Compile/Target SDK 35
- Java 17
- GitHub Actions uses Gradle 8.7
- Workflow builds `app-debug.apk` directly from the project root (no nested ZIP extraction step).

## Included fixes
- 4-second animated CashBook / RMT Labs splash
- Password setup and SHA-256 password verification
- Biometric unlock with password fallback
- Safer biometric API handling on Android 9/10+
- Contact picker bridge
- EMI / loan reminder notification bridge
- Android 13 notification permission handling
- Shared Expense settlement flow
- AED / INR currency exchange tracking
- Backup / restore and email backup bridge
- First-run guided tutorial reset for V14.6.2
- Removed unnecessary cleartext traffic and OS app-data backup; use CashBook's explicit Backup & Restore instead


## V14.6.2
Authentication flow starts with Login / Sign Up; password and biometric are only available after account authentication. See AUTH_FLOW_V14.6.2.md.
