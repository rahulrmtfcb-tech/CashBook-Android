# CashBook V12

CashBook V12 is a refreshed Android personal-finance tracker powered by RMT Labs.

## V12 fixes and improvements
- Animated CashBook splash using a real vector app mark instead of an emoji placeholder.
- Proper Android launcher/round icon.
- Guided first-run tutorial and reusable Help/Tutorial menu.
- Income, Expense, Loan Given, Loan Taken, repayments and EMI history.
- Dividend-adjusted EMI payable with actual payment amount and remaining amount validation.
- Monthly Summary for income, expenses, loans, repayments, EMI and currency exchange.
- AED/INR/USD/SAR balances; zero-balance currencies stay hidden.
- Currency conversion validates amount/rate and updates both sides correctly.
- Backup/restore upgraded to V12 naming while remaining compatible with earlier JSON backups.
- Native Android reminders scheduled 7 days before EMI/loan due dates when notification permission is allowed.
- Existing WebView data remains local on the device.

## Build
GitHub Actions workflow builds `app-debug.apk` with Gradle and Java 17.
